<?php

include_once 'connection.php';
include 'logout.php';
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;

}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  max-width: 900px;
  max-height: 900px;
  padding-left:  400px;

  background-color: white;
}

/* Full-width input fields */
input[type=text], textarea,input[type=number],input[type=password],input[type=file],input[type=mail],input[type=date],input[type=textarea],input[type=radio],input[type=checkbox],select ,input[pattern]{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
table, th, td {
  border: 1px solid black;
}
input[type=text]:focus, input[type=date]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}
.registerbtn2 {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin-left: 120px;
 
  border: none;

  cursor: pointer;
  width: 30%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>

<form method="POST" enctype="multipart/form-data" action="user_postdb.php">
  <div class="container">
    <h1> Add Post    <button type="submit" formaction="logout.php?action=logout" class="registerbtn2"   >Logout</button></h1>

    <hr>
 <label for="email"><b> Title </b></label>
    <input type="text" placeholder="Enter Description" name="title">
   


 <label for="email"><b> Description </b></label>
 <textarea  placeholder="Enter Description" name="des" > </textarea>
   
    <label for="psw-repeat"><b>Status</b></label>

    <select  name="status" class="form-control">
<option selected disabled>--Select Status--</option>
<option value="Active">Active</option>
<option value="De_Active">De-Active</option>

</select>


    <button type="submit" class="registerbtn"  name='submit' >Add Post</button>
  
</form>
  <h4 style="text-align: center;"> Post Details</h4>
            <table class="table " style="border: 30px; border-color:black; height: 100px;
            width: 500px"> 

           
<?php
include_once 'connection.php';
$id= $_SESSION["user_id"];


$ret=mysqli_query($con,"SELECT * FROM tbl_post,tbl_user where tbl_user.user_id=tbl_post.user_id and tbl_post.user_id=$id");
              
    $counter=1;
    if($ret)
{
    if(mysqli_num_rows($ret) > 0)
    {
      
    echo "<thead>
               <tr height='100px' ><th>Sr.No</th> 

<th width='200px'>Title</th>



                <th width='200px'> Description</th>
                <th width='200px'>Status</th>
               
                   <th width='200px'>Update
                </th>
                   <th width='200px'>Delete
                </th>
                </tr> </thead>";
while($row = mysqli_fetch_array($ret))
{

echo "<tr height='100px' width='100px'>";


 echo "<td width='200px'>". $counter++ ."</td>";
 $id=$row['post_id'];
echo  "<td width='200px'>" . $row['Title'] ."</td>";
echo  "<td width='200px'>" . $row['Description'] ."</td>";
echo  "<td width='200px'>" . $row['status'] ."</td>";

echo "<td width='200px'><a href='post_update.php?id=$id'><i class='fa fa-edit' aria-hidden='true'></i</a></td>";

echo "<td width='200px'><a href='post_delete.php?del=del&id=$id'><i class='fa fa-remove' aria-hidden='true'></i</a></td>";

              echo "</tr>";

                }



        echo "</table>";
        // Free result set
        mysqli_free_result($ret);
    } else
    {
      
 
      
        echo "No any post  add...!!!";
    }
} else
{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}


             ?>
          </table>
</body>


</html>

