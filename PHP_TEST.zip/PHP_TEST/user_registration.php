<?php

include_once 'connection.php';
include 'logout.php';
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script type="text/javascript">


    var check = function() {
  if (document.getElementById('password').value ==
    document.getElementById('confirm_password').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'matching';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'not matching';
  }
}
</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;

}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  max-width: 900px;
  max-height: 900px;
  padding-left:  400px;

  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=number],input[type=password],input[type=file],input[type=mail],input[type=date],input[type=textarea],input[type=radio],input[type=checkbox],select ,input[pattern]{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
table, th, td {
  border: 1px solid black;
}
input[type=text]:focus, input[type=date]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>

<form method="POST" enctype="multipart/form-data" action="user_registrationdb.php">
  <div class="container">
    <h1> User Register</h1>

    <hr>

    <label for="email"><b> Name</b></label>
    <input type="text" placeholder="Enter name" name="name" required=""/>
    <label for="email"><b> Address </b></label>
    <input type="text" placeholder="Enter Address" name="address" required=""/>
    <label for="psw-repeat"><b>Gender</b></label>

    <select  name="gender" class="form-control">
<option selected disabled>--Select Student Gender--</option>
<option value="Male">Male</option>
<option value="Female">Female</option>

</select>

  
     <label for="email"><b>Contact Number</b></label>
    <input type="text" placeholder="Enter Mobile No" name="mob" minLength="10" maxLength="10" required=""/>

    
     <label for="email"><b>Email</b></label>
    <input   pattern="[a-zA-Z0-9!#$%&amp'*+\/=?^_`{|}~.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*"type="email" placeholder="Enter Email" name="mail"  required=""/>  

    <label for="email"><b> Password</b></label>
    <input type="password" placeholder="Enter password" name="password" id="password" type="password"  minLength="7" maxLength="8"  required=""/>
      <label for="email"><b>Confirm Password</b></label>
    <input type="password" placeholder="Enter password"  name="confirm_password" id="confirm_password"  onkeyup='check();' /> 
  <span id='message'></span>

    <button type="submit" class="registerbtn"  name='add' >Register</button>
  
</form>

</body>
<script type="text/javascript">
 


function checkForm(form)
  {

 

    if(form.password.value != "" && form.password.value == form.confirmpassword.value) 
    {
      if(form.password.value.length < 6) 
      {
        alert("Error: Password must contain at least six characters!");
        form.password.focus();
        return false;
      }

      
      re = /[0-9]/;
      if(!re.test(form.password.value))
       {
        alert("Error: password must contain at least one number (0-9)!");
        form.password.focus();
        return false;
      }

      re = /[a-z]/;
      if(!re.test(form.password.value)) 
      {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        form.password.focus();
        return false;
      }

      re = /[A-Z]/;
      if(!re.test(form.password.value)) 
      {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        form.password.focus();
        return false;
      }
  }
 
    else
     {
      alert("Error: Please check that you've entered and confirmed your password!");
      form.password.focus();
      return false;
    }
}
</script>
</html>

