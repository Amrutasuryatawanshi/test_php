<?php 
require_once('connection.php');

try
{
    if(isset($_POST['submit']))

    { 
      session_start();
      
          $mobno=$_POST['mobno'];
          $password=$_POST['password'];

              if(empty($mobno) || empty($password))
              {
                  echo "Please Fill The Details !";
              }
              else
              {
                $query = mysqli_query($con,"SELECT * FROM  tbl_user WHERE mob_number = '$mobno' AND password = '$password' ");
                  $row=mysqli_fetch_assoc($query);
                        if($row)
                       {
                               $_SESSION["user_id"]=$row["user_id"];
                                 echo "<script>alert('correct Username And Password !'');</script>";
                                    echo "<script >document.location ='user_post.php';</script>";
                                      
                        }
                        else
                        {
                                       echo "<script>alert(' Wrong Username And Password !'');</script>";
                                    echo "<script >document.location ='user_login.php';</script>";
                        }   
              }
                      

}

 }       
catch(expection $exp)
{
 echo $exp;
}                         
?>



























