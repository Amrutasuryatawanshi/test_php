<?php
include_once 'connection.php';
try
{

   if(isset($_POST['submit']))
    {
 $name=$_POST['title'];

 $gender=$_POST['des'];

 $mob=$_POST['status'];

 $id= $_SESSION["user_id"];
   $date = date('Y-m-d H:i:s');
 $query3=mysqli_query($con,"insert into tbl_post(Title ,Description, status,  created_at , user_id )value( '$name','$gender','$mob','$date',$id)");
 if ( $query3) 
    {
    echo "<script>alert('You have successfully add New  Post...!!!');</script>";
echo "<script >document.location ='user_post.php';</script>";
    }
    else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }

}
}
catch(expection $exp)
{
 echo $exp;
} 
?>