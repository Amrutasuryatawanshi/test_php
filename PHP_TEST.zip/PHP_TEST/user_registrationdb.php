<?php
include_once 'connection.php';

 $password=$_POST['password'];
  $confirm_password=$_POST['confirm_password'];

if($password==$confirm_password)
{

 $name=$_POST['name'];
 $address=$_POST['address'];
 $gender=$_POST['gender'];

 $mob=$_POST['mob'];

 $mail=$_POST['mail'];
 $password=$_POST['password'];



 $query3=mysqli_query($con,"insert into tbl_user(  name ,address,gender,  mob_number ,mailid, password  )value( '$name','$address','$gender','$mob','$mail','$password')");
 if ( $query3) 
    {
    echo "<script>alert('You have successfully Register...!!!');</script>";
echo "<script >document.location ='user_login.php';</script>";
    }
    else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }
  }
  else
  {
  echo "<script>alert('Your Enter Password is wrong enter correct password...!!!');</script>";
echo "<script >document.location ='user_login.php';</script>";

  }

?>