<?php
include_once 'connection.php';
include 'logout.php';
try
{
 
if(isset($_GET['del']))
    {

 $id=$_GET['id'];
 $id= $_SESSION["user_id"];
 $query4=mysqli_query($con,"delete from tbl_post where post_id = $id");
 if ( $query4) 
    {
    echo "<script>alert('You have Delete Post...!!!');</script>";
echo "<script >document.location ='user_post.php';</script>";
    }
    else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }
}

}
catch(expection $exp)
{
 echo $exp;
} 
?>