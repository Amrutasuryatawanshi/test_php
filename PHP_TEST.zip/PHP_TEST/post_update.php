<?php
include_once 'connection.php';

include 'logout.php';
?>
<?php
try
{

if(isset($_POST['update']))
    {
 

 $name=$_POST['title'];
 $id= $_SESSION["user_id"];
 $des=$_POST['des'];

 $st=$_POST['status'];
 $id=$_POST['id'];

 $query3=mysqli_query($con, "UPDATE tbl_post SET Title='$name' ,Description='$des' ,status='$st' 
 where post_id = $id ");
 if ( $query3) 
    {
    echo "<script>alert('You have successfully update   post...!!!');</script>";
echo "<script >document.location ='user_post.php';</script>";
    }
    else
    {
      echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }

}


}
catch(expection $exp)
{
 echo $exp;
} 
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;

}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  max-width: 900px;
  max-height: 900px;
  padding-left:  400px;

  background-color: white;
}

/* Full-width input fields */
input[type=text], textarea,input[type=number],input[type=password],input[type=file],input[type=mail],input[type=date],input[type=textarea],input[type=radio],input[type=checkbox],select ,input[pattern]{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
table, th, td {
  border: 1px solid black;
}
input[type=text]:focus, input[type=date]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
.registerbtn2 {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin-left: 120px;
 
  border: none;

  cursor: pointer;
  width: 30%;
  opacity: 0.9;
}
</style>
</head>
<body>

<form method="POST" enctype="multipart/form-data" action="post_update.php">
  <div class="container">
    <h1> Update Post  <button type="submit" formaction="logout.php?action=logout" class="registerbtn2"  name='submit' >Logout</button></h1>

    <hr>
    <?php
   
$idr=$_GET['id'];
 $id= $_SESSION["user_id"];
$res=mysqli_query($con,"select * from  tbl_post where
 post_id= $idr ");
$row = mysqli_fetch_array($res);

    
      ?>
 <label for="email"><b> Title </b></label>
    <input type="text"  value="<?php  echo $row['Title'];?>" name="title">
   


 <label for="email"><b> Description </b></label>
 <input type="text" value="<?php  echo $row['Description'];?>" name="des" > 
    <input type="hidden" value="<?php  echo $row['post_id'];?>" name="id" > 
    <label for="psw-repeat"><b>Status</b></label>

    <select  name="status" class="form-control">
<option  value="<?php  echo $row['status'];?>"> <?php  echo $row['status'];?></option>
<option value="Active">Active</option>
<option value="De_Active">De-Active</option>

</select>


    <button type="submit" class="registerbtn"  name='update' >Update</button>
  
</form>
  
</body>


</html>

